export interface Actor {
  name: string;
  rating: number;
  city?: string;
}
