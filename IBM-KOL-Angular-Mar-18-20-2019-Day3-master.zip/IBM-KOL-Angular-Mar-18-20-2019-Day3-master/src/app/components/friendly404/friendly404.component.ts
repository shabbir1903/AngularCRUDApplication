import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-friendly404',
  templateUrl: './friendly404.component.html',
  styleUrls: ['./friendly404.component.css']
})
export class Friendly404Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
